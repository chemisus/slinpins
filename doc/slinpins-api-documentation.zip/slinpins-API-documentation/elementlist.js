
var ApiGen = ApiGen || {};
ApiGen.elements = [["c","Closure"],["c","MockTest"],["c","ReflectionFunction"],["c","ReflectionFunctionAbstract"],["c","ReflectionMethod"],["c","Reflector"],["c","Scope"],["c","ScopeTest"]];
